class Word < ActiveRecord::Base
	
	def self.search search
		
	end

end

